import platform
import socket
import sounddevice as sd
import psutil
import cv2
import os
import logging 
import sqlite3
import time
from pathlib import Path
from contextlib import closing
from threading import Lock
from flask import Flask, render_template, redirect, url_for, request, Response, jsonify, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_cors import CORS
from flask_socketio import SocketIO, emit
from ultralytics import YOLO

app = Flask(__name__, template_folder='D:/8th sem/Malpractice/malprac/templates')
app.secret_key = os.getenv('SECRET_KEY', 'supersecretkey')
socketio = SocketIO(app, cors_allowed_origins='*')
websocket_url = os.getenv('WEBSOCKET_URL','wss://127.0.0.1:5000')
CORS(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Initialize video capture and object detection model
cap = None
model = YOLO(".venv/yolo-Weights/yolov8n.pt")

# Define class names for YOLO object detection
classNames = [...]  # Your existing class names

detected_objects = {}
lock = Lock()
student_access = {}
access_requests = []

# Define User class for login management
class User(UserMixin):
    def __init__(self, id):
        self.id = id

# User data
users = {}

@login_manager.user_loader
def load_user(user_id):
    return User(user_id) if user_id in users else None

def initialize_db():
    try:
        with closing(sqlite3.connect('D:/8th sem/Malpractice/exam_result.db')) as conn:
            cursor = conn.cursor()
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS exam_result (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT NOT NULL UNIQUE,
                email TEXT NOT NULL,
                name TEXT NOT NULL
            )
            ''')
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS exam_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT NOT NULL,
                exam_name TEXT NOT NULL,
                score INTEGER NOT NULL,
                FOREIGN KEY (student_id) REFERENCES students (student_id)
            )
            ''')
            conn.commit()
    except sqlite3.Error as e:
        print(f"Database initialization error: {e}")

initialize_db()

# Function to check available cameras
def get_camera_index():
    cap = cv2.VideoCapture(1)
    if cap.isOpened():
        cap.release()
        return 1
    cap = cv2.VideoCapture(0)
    if cap.isOpened():
        cap.release()
        return 0
    return None

# Video feed generator
def generate_frames():
    global detected_objects, cap
    camera_index = get_camera_index()
    if camera_index is None:
        yield b'No camera found'
        return

    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        results = model(frame, stream=True)
        current_detected_objects = {}
        for r in results.pandas().xyxy:
            for index, obj in r.iterrows():
                x1, y1, x2, y2 = int(obj['xmin']), int(obj['ymin']), int(obj['xmax']), int(obj['ymax'])
                class_name = classNames[int(obj['class'])]
                cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
                cv2.putText(frame, class_name, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
                timestamp = time.strftime('%H:%M:%S', time.localtime())
                current_detected_objects[f'{class_name} - {timestamp}'] = timestamp

        with lock:
            detected_objects.update(current_detected_objects)

        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame/r/n'
               b'Content-Type: image/jpeg/r/n/r/n' + frame + b'/r/n')

    cap.release()

# Routes

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username]['password'] == password:
            user = User(username)
            login_user(user)
            return redirect(url_for('admin') if username == 'admin' else url_for('student'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

# Register route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users:
            flash('Username already exists')
        else:
            users[username] = {'password': password}
            flash('Registration successful, please log in')
            return redirect(url_for('login'))
    return render_template('register.html')

# Logout route
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# Video feed route
@app.route('/video_feed')
@login_required
def video_feed():
    if current_user.id == 'admin' or (current_user.id == 'student' and student_access.get(current_user.id, False)):
        return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')
    return redirect(url_for('index'))

# Detected objects route
@app.route('/detected_objects')
@login_required
def get_detected_objects():
    with lock:
        return jsonify(detected_objects)

# Admin route
@app.route('/admin')
@login_required
def admin():
    if current_user.id != 'admin':
        return redirect(url_for('login'))
    return render_template('admin.html')

# Student route
@app.route('/student')
@login_required
def student():
    if current_user.id != 'student':
        return redirect(url_for('login'))
    return render_template('student.html')

# Access request
@app.route('/request_access', methods=['POST'])
@login_required
def request_access():
    if current_user.id == 'student':
        access_requests.append({'student': current_user.id, 'timestamp': time.time()})
        return jsonify({'access_requested': True})
    return jsonify({'error': 'Unauthorized'}), 403

# Admin notifications route
@app.route('/admin/notifications', methods=['GET'])
@login_required
def get_notifications():
    if current_user.id == 'admin':
        return jsonify({'requests': access_requests})
    return jsonify({'error': 'Unauthorized'}), 403

# Check access route
@app.route('/check-access', methods=['GET'])
@login_required
def check_access():
    if student_access.get(current_user.id, False):
        return jsonify({'access': True})
    return jsonify({'access': False})

# Grant access route
@app.route('/grant-access', methods=['POST'])
@login_required
def grant_access():
    global access_requests
    if current_user.id == 'admin':
        data = request.json
        if data.get('grant_all'):
            for user in users:
                if user != 'admin':
                    student_access[user] = True
            access_requests.clear()
            return jsonify({'access_granted': True})
        else:
            student_id = data.get('student')
            if student_id in users:
                student_access[student_id] = True
                access_requests = [req for req in access_requests if req['student'] != student_id]
                return jsonify({'access_granted': True})
    return jsonify({'error': 'Unauthorized'}), 403

# Start feed route
@app.route('/start_feed')
@login_required
def start_feed():
    global student_access, cap
    if current_user.id == 'admin':
        if cap is None or not cap.isOpened():
            camera_index = get_camera_index()
            if camera_index is not None:
                cap = cv2.VideoCapture(camera_index)
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            else:
                return jsonify({'status': 'No camera found'}), 400
        student_access[current_user.id] = True
    return jsonify({'status': 'Feed started'})

# Stop feed route
@app.route('/stop_feed')
@login_required
def stop_feed():
    global student_access, cap
    if current_user.id == 'admin':
        student_access[current_user.id] = False
        if cap and cap.isOpened():
            cap.release()
            cap = None
    return jsonify({'status': 'Feed stopped'})

@app.route('/system_check')
@login_required
def system_check():
    if current_user.id != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    try:
        system_info = {
            "os": check_operating_system(),
            "network": check_network_connectivity(),
            "webcam": check_webcam_availability(),
            "microphone": check_microphone(),
            "browsers": detect_running_browsers(),
        }
        return jsonify(system_info)
    except Exception as e:
        logging.error(f"System check error: {str(e)}")  # Log the error for debugging
        return jsonify({'error': 'Internal server error'}), 500

# Exam data
exam_data = {
    'exam_id': 1,
    'title': 'Sample Exam',
    'questions': [
        {'question_id': 1, 'text': 'What is the capital of France?', 'options': ['Paris', 'London', 'Berlin', 'Madrid'], 'answer': 'Paris', 'type': 'multiple-choice'},
        {'question_id': 2, 'text': 'What is 2 + 2?', 'options': ['3', '4', '5', '6'], 'answer': '4', 'type': 'multiple-choice'},
        {'question_id': 3, 'text': 'What is the capital of Japan?', 'options': ['Tokyo', 'Beijing', 'Seoul', 'Bangkok'], 'answer': 'Tokyo', 'type': 'multiple-choice'},
        {'question_id': 4, 'text': 'What is the largest planet in our solar system?', 'options': ['Mercury', 'Venus', 'Earth', 'Jupiter'], 'answer': 'Jupiter', 'type': 'multiple-choice'},
        {'question_id': 5, 'text': 'What is the full form of HTML?', 'options': ['Hyper Text Markup Language', 'Hyperlinks and Text Markup Language', 'Home Tool Markup Language', 'None of the above'], 'answer': 'Hyper Text Markup Language', 'type': 'multiple-choice'},
        {'question_id': 6, 'text': 'Write a Python function to calculate the factorial of a number.', 'answer': 'def factorial(n):\n    if n == 0:\n        return 1\n    else:\n        return n * factorial(n-1)', 'type': 'coding'},
        {'question_id': 7, 'text': 'Write a Python function to check if a number is prime.', 'answer': 'def is_prime(n):\n    if n <= 1:\n        return False\n    for i in range(2, int(n**0.5) + 1):\n        if n % i == 0:\n            return False\n    return True', 'type': 'coding'},
        {'question_id': 8, 'text': 'What is the largest ocean on Earth?', 'options': ['Atlantic Ocean', 'Arctic Ocean', 'Indian Ocean', 'Pacific Ocean'], 'answer': 'Pacific Ocean', 'type': 'multiple-choice'},
        {'question_id': 9, 'text': 'What is the powerhouse of the cell?', 'options': ['Nucleus', 'Cytoplasm', 'Mitochondria', 'Ribosome'], 'answer': 'Mitochondria', 'type': 'multiple-choice'},
        {'question_id': 10, 'text': 'What is the smallest bone in the human body?', 'options': ['Malleus', 'Stapes', 'Incus', 'Femur'], 'answer': 'Stapes', 'type': 'multiple-choice'}
    ]
}

# Route to get the entire exam data
@app.route('/exam', methods=['GET'])
def get_exam():
    return jsonify(exam_data)

# Route to get a specific question by question_id
@app.route('/exam/question/<int:question_id>', methods=['GET'])
def get_question(question_id):
    for question in exam_data['questions']:
        if question['question_id'] == question_id:
            return jsonify(question)
    return jsonify({'error': 'Question not found'}), 404

# Exam page route
@app.route('/')
def index():
    return render_template('examapi.html')

#WebSocket route
@app.route('/config', methods=['GET'])
def get_config():
    websocket_url = os.getenv('WEBSOCKET_URL', 'wss://127.0.0.1:5000')
    return jsonify({'websocketUrl': websocket_url})

# Exam API route
@app.route('/examapi')
@login_required
def examapi():
    return render_template('examapi.html', exam_data=exam_data)

# Submit exam
@app.route('/submit_exam', methods=['POST'])
def submit_exam():
    try:
        student_id = request.args.get('student')
        if not student_id:
            return jsonify({"status": "error", "message": "Student ID is required"}), 400
        
        data = request.json
        if not data:
            return jsonify({"status": "error", "message": "No exam data provided"}), 400

        save_exam_data(student_id, data)
        return jsonify({"status": "success", "message": "Exam submitted successfully!"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/student-results', methods=['GET'])
def get_student_results():
    student_id = request.args.get('student')
    if not student_id:
        return jsonify({'error': 'Student ID is required'}), 400
    
    conn = sqlite3.connect('D:/8th sem/Malpractice/exam_result.db')
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM exam_results WHERE student_id = ?', (student_id,))
    student = cursor.fetchone()
    
    cursor.execute('SELECT * FROM exam_results WHERE student_id = ?', (student_id,))
    results = cursor.fetchall()
    
    conn.close()
    
    if student and results:
        return jsonify({
            'student': {
                'id': student[0],
                'name': student[2],
                'email': student[1],
            },
            'results': [dict(zip(['exam_name', 'score'], result[2:])) for result in results]
        })
    else:
        return jsonify({'error': 'Student not found or no results available'}), 404

# Function to save exam data into the database
def save_exam_data(student_id, exam_data):
    conn = sqlite3.connect('D:/8th sem/Malpractice/exam_result.db')
    cursor = conn.cursor()
    
    # Insert exam results
    for question_id, answer in exam_data.items():
        cursor.execute('INSERT INTO exam_results (student_id, question_id, answer) VALUES (?, ?, ?)', (student_id, question_id, answer))
    
    conn.commit()
    conn.close()

# Function to fetch exam results from the database
def fetch_exam_results(student_id):
    connection = sqlite3.connect('D:/8th sem/Malpractice/exam_result.db')
    cursor = connection.cursor()
    
    try:
        cursor.execute('SELECT question_id, answer FROM exam_results WHERE student_id = ?', (student_id,))
        result = cursor.fetchall()
    except sqlite3.OperationalError as e:
        print(f"Database error: {e}")
        result = None
    finally:
        connection.close()
    
    return result

# Error handling
@app.errorhandler(401)
def unauthorized(error):
    return jsonify({'error': 'Unauthorized access'}), 401

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

# Function to check operating system
def check_operating_system():
    return platform.platform()

# Function to check network connectivity
def check_network_connectivity():
    try:
        socket.create_connection(("www.google.com", 80))
        return "Network is up"
    except OSError:
        return "Network is down"

# Function to check webcam availability
def check_webcam_availability():
    camera_index = get_camera_index()
    if camera_index is not None:
        return f"Webcam found at index {camera_index}"
    else:
        return "No webcam found"

# Function to check microphone availability
def check_microphone():
    try:
        sd.query_devices()
        return "Microphone found"
    except OSError:
        return "No microphone found"

# Function to detect running browsers
def detect_running_browsers():
    browsers = []
    for proc in psutil.process_iter(['pid', 'name']):
        if 'chrome' in proc.info['name'].lower() or 'firefox' in proc.info['name'].lower():
            browsers.append(proc.info['name'])
    return browsers

@socketio.on('offer')
def handle_offer(data):
    emit('offer', data, broadcast=True)

@socketio.on('answer')
def handle_answer(data):
    emit('answer', data, broadcast=True)

@socketio.on('iceCandidate')
def handle_ice_candidate(data):
    emit('iceCandidate', data, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
