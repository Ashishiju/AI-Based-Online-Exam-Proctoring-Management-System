import logging
import traceback
from flask import Flask, render_template, redirect, url_for, request, Response, jsonify, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import cv2
from ultralytics import YOLO
from threading import Thread, Lock, Timer
import time
import os
import signal
import face_recognition
import platform
import socket
import subprocess
import sounddevice as sd
import psutil

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Secure random secret key

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

cap = None
model = YOLO("yolo-Weights/yolov8n.pt")

classNames = ["person", "bicycle", "car", "motorbike", "aeroplane", "bus", "train", "truck", "boat",
              "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat",
              "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella",
              "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite", "baseball bat",
              "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup",
              "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange", "broccoli",
              "carrot", "hot dog", "pizza", "donut", "cake", "chair", "sofa", "pottedplant", "bed",
              "diningtable", "toilet", "tvmonitor", "laptop", "mouse", "remote", "keyboard", "cell phone",
              "microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors",
              "teddy bear", "hair drier", "toothbrush"]

detected_objects = {}
lock = Lock()
student_access = False

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
known_face_encodings = []
known_face_names = []

def load_known_faces():
    image_files = [r'C:\Users\mnvin\OneDrive\Pictures\Camera Roll\WIN_20240702_12_19_46_Pro.jpg']
    for image_file in image_files:
        try:
            image = face_recognition.load_image_file(image_file)
            encoding = face_recognition.face_encodings(image)[0]
            known_face_encodings.append(encoding)
            known_face_names.append(os.path.basename(image_file))
        except Exception as e:
            app.logger.error(f"Error loading face image {image_file}: {e}")

load_known_faces()

class User(UserMixin):
    def __init__(self, id):
        self.id = id

users = {'admin': {'password': '123'}, 'student': {'password': '123'}}

@login_manager.user_loader
def load_user(user_id):
    return User(user_id)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username]['password'] == password:
            user = User(username)
            login_user(user)
            if username == 'admin':
                return redirect(url_for('admin'))
            else:
                return redirect(url_for('student'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

def generate_frames():
    global detected_objects
    while True:
        if not cap or not cap.isOpened():
            continue
        try:
            success, frame = cap.read()
            if not success:
                break

            results = model(frame, stream=True)
            current_detected_objects = {}
            for r in results.pred:
                for det in r:
                    class_name = classNames[det[-1]]
                    if class_name not in current_detected_objects:
                        current_detected_objects[class_name] = []
                    current_detected_objects[class_name].append(det.tolist())

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 3)
                cv2.putText(frame, "Vinay", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

            with lock:
                detected_objects.update(current_detected_objects)

            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()

            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        except Exception as e:
            app.logger.error(f"Error generating frame: {e}")

@app.route('/video_feed')
@login_required
def video_feed():
    if current_user.id == 'admin' or (current_user.id == 'student' and student_access):
        return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')
    return redirect(url_for('login'))

@app.route('/detected_objects')
@login_required
def get_detected_objects():
    with lock:
        return jsonify(detected_objects)

@app.route('/admin')
@login_required
def admin():
    if current_user.id != 'admin':
        return redirect(url_for('login'))
    return render_template('admin.html')

@app.route('/student')
@login_required
def student():
    if current_user.id != 'student':
        return redirect(url_for('login'))
    return render_template('student.html')

@app.route('/start_feed')
@login_required
def start_feed():
    global student_access, cap
    if current_user.id == 'admin':
        if cap is None or not cap.isOpened():
            cap = cv2.VideoCapture(0)
            cap.set(3, 640)
            cap.set(4, 480)
        student_access = True
    return jsonify({'status': 'Feed started'})

@app.route('/stop_feed')
@login_required
def stop_feed():
    global student_access, cap
    if current_user.id == 'admin':
        student_access = False
        if cap and cap.isOpened():
            cap.release()
            cap = None
    return jsonify({'status': 'Feed stopped'})

@app.route('/check_access')
@login_required
def check_access():
    global student_access
    return jsonify({'access': student_access})

def check_operating_system():
    try:
        os_name = platform.system()
        return f"{os_name}"
    except Exception as e:
        app.logger.error(f"Error checking operating system: {e}")
        return "Error"

def check_network_connectivity():
    try:
        socket.create_connection(("www.google.com", 80))
        return "Connected"
    except OSError:
        return "Disconnected"

def check_webcam_availability():
    try:
        command = "ls /dev/video*"
        output = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
        return "Available" if output else "Not Available"
    except subprocess.CalledProcessError:
        return "Not Available"

def check_microphone():
    try:
        mic_info = sd.query_devices(kind='input')
        return "Available" if mic_info else "Not Available"
    except Exception as e:
        return f"Microphone check error: {str(e)}"

def detect_running_browsers():
    try:
        browsers = []
        for process in psutil.process_iter(['pid', 'name']):
            if "chrome" in process.info['name'].lower():
                browsers.append("Google Chrome")
            elif "firefox" in process.info['name'].lower():
                browsers.append("Mozilla Firefox")
            elif "edge" in process.info['name'].lower():
                browsers.append("Microsoft Edge")
        return browsers
    except Exception as e:
        app.logger.error(f"Error detecting running browsers: {e}")
        return []

@app.route('/system_check')
@login_required
def system_check():
    if current_user.id != 'admin':
        return redirect(url_for('login'))

    try:
        os_info = check_operating_system()
        network_info = check_network_connectivity()
        webcam_info = check_webcam_availability()
        mic_info = check_microphone()
        browsers_info = detect_running_browsers()

        system_info = {
            "Operating System": os_info,
            "Network": network_info,
            "Webcam": webcam_info,
            "Microphone": mic_info,
            "Browsers": browsers_info,
        }
        return jsonify(system_info)
    except Exception as e:
        app.logger.error(f"Error performing system check: {e}")
        return jsonify({"error": "Error performing system check"})

questions = [
    {"question": "What is the capital of France?", "options": ["Paris", "London", "Berlin", "Madrid"], "answer": "Paris"},
    {"question": "What is 2 + 2?", "options": ["3", "4", "5", "6"], "answer": "4"},
    {"question": "What is the color of the sky?", "options": ["Blue", "Green", "Red", "Yellow"], "answer": "Blue"},
    {"question": "Which planet is known as the Red Planet?", "options": ["Earth", "Mars", "Jupiter", "Saturn"], "answer": "Mars"},
    {"question": "What is the largest ocean on Earth?", "options": ["Atlantic", "Indian", "Arctic", "Pacific"], "answer": "Pacific"}
]

@app.route('/exam', methods=['GET', 'POST'])
@login_required
def exam():
    if current_user.id != 'student':
        return redirect(url_for('login'))

    if request.method == 'POST':
        try:
            answer = request.form.get('answer')
            question_index = int(request.form.get('question_index'))
            if answer == questions[question_index]['answer']:
                flash('Correct answer!')
            else:
                flash('Wrong answer!')
            next_question_index = question_index + 1
            if next_question_index >= len(questions):
                return redirect(url_for('exam_end'))
            return redirect(url_for('exam_question', question_index=next_question_index))
        except Exception as e:
            app.logger.error(f"Error handling exam submission: {e}")
            flash('Error processing your answer.')
            return redirect(url_for('exam_question', question_index=question_index))

    return redirect(url_for('exam_question', question_index=0))

@app.route('/exam/question/<int:question_index>', methods=['GET'])
@login_required
def exam_question(question_index):
    if current_user.id != 'student':
        return redirect(url_for('login'))

    if question_index >= len(questions):
        return redirect(url_for('exam_end'))

    question = questions[question_index]
    return render_template('exam_question.html', question=question, question_index=question_index, time_limit=60)

@app.route('/exam/end', methods=['GET'])
@login_required
def exam_end():
    if current_user.id != 'student':
        return redirect(url_for('login'))

    return render_template('exam_end.html')

def schedule_shutdown(delay):
    def shutdown():
        os.kill(os.getpid(), signal.SIGINT)
    Timer(delay, shutdown).start()

if __name__ == "__main__":
    logging.basicConfig(level=logging.ERROR)
    schedule_shutdown(1200)
    app.run(debug=True)
