import platform
import subprocess
import socket
import sounddevice as sd
import psutil


# Function to check the system's operating system
def check_operating_system():
    os_name = platform.system()
    print(f"Operating System : {os_name}\n")


# Function to check network connectivity
def check_network_connectivity():
    try:
        socket.create_connection(("www.google.com", 80))
        print("Network connectivity : Connected\n")
    except OSError:
        print("Network connectivity : Disconnected\n")


# Function to check webcam availability
def check_webcam_availability():
    command = "ls /dev/video*"
    try:
        output = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
        if output:
            print("Webcam availability : Available\n")
        else:
            print("Webcam availability : Not available\n")
    except subprocess.CalledProcessError:
        print("Webcam availability : Available\n\n")

        def check_microphone():
            # Query the default microphone device info
            mic_info = sd.query_devices(kind='input')

            if mic_info:
                print("Microphone Availablity : Available\n")
                print("Microphone Name :", mic_info['name'])
                print("Max Input Channels :", mic_info['max_input_channels'])
                print("Default Sample Rate :", mic_info['default_samplerate'])
            else:
                print("No microphone available.\n")

        if __name__ == "__main__":
            check_microphone()

        def detect_running_browsers():
            browsers = []
            for process in psutil.process_iter(['pid', 'name']):
                if "chrome" in process.info['name'].lower():
                    browsers.append("Google Chrome")
                elif "firefox" in process.info['name'].lower():
                    browsers.append("Mozilla Firefox")
                elif "edge" in process.info['name'].lower():
                    browsers.append("Microsoft Edge")
                # Add more conditions for other browsers if needed
            return browsers

        if __name__ == "__main__":
            running_browsers = detect_running_browsers()
            if running_browsers:
                print("\nRunning web browsers :\n")
                for browser in running_browsers:
                    print(browser)
            else:
                print("No web browsers are running.")


# Function to perform the system check
def perform_system_check():
    print("Starting system check...\n")
    check_operating_system()
    check_network_connectivity()
    check_webcam_availability()
    print("\nSystem check completed.")


# Example usage
if __name__ == "__main__":
    perform_system_check()